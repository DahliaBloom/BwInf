# Aufgabe 4 BWINF 2023
This is the submission of Benno Kolar, if you wish to run the Website, make sure you have NPM, VueJS, Tailwind and DaisyUI installed.